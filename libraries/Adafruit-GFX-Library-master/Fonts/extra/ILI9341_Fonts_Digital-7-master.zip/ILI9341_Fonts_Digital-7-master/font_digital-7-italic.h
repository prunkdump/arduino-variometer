#ifndef _ILI9341_t3_font_digital-7-italic_
#define _ILI9341_t3_font_digital-7-italic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Digital7_8_Italic;
extern const ILI9341_t3_font_t Digital7_9_Italic;
extern const ILI9341_t3_font_t Digital7_10_Italic;
extern const ILI9341_t3_font_t Digital7_11_Italic;
extern const ILI9341_t3_font_t Digital7_12_Italic;
extern const ILI9341_t3_font_t Digital7_13_Italic;
extern const ILI9341_t3_font_t Digital7_14_Italic;
extern const ILI9341_t3_font_t Digital7_16_Italic;
extern const ILI9341_t3_font_t Digital7_18_Italic;
extern const ILI9341_t3_font_t Digital7_20_Italic;
extern const ILI9341_t3_font_t Digital7_24_Italic;
extern const ILI9341_t3_font_t Digital7_28_Italic;
extern const ILI9341_t3_font_t Digital7_32_Italic;
extern const ILI9341_t3_font_t Digital7_40_Italic;
extern const ILI9341_t3_font_t Digital7_48_Italic;
extern const ILI9341_t3_font_t Digital7_60_Italic;
extern const ILI9341_t3_font_t Digital7_72_Italic;
extern const ILI9341_t3_font_t Digital7_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
